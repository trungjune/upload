﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
namespace UploadImages
{
    public partial class Default : System.Web.UI.Page
    {
        public SqlConnection con;

        public void connection()
        {

            string constr = ConfigurationManager.ConnectionStrings["image"].ToString();
            con = new SqlConnection(constr);
            con.Open();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;
        }


        protected void Button1_Click(object sender, EventArgs e)
        {

            if (!FileUpload1.HasFile)
            {
                Label1.Visible = true;
                Label1.Text = "Please Select Image File";

            }
            else
            {
                int length = FileUpload1.PostedFile.ContentLength;
                byte[] pic = new byte[length];

                FileUpload1.PostedFile.InputStream.Read(pic, 0, length);
              
                try
                {
                    connection();
                    SqlCommand com = new SqlCommand("insert into ImageTotable "
                      + "(myphoto,name) values (@photo, @name)", con);
                    com.Parameters.AddWithValue("@photo", pic);
                    com.Parameters.AddWithValue("@name", TextBox1.Text);
                    com.ExecuteNonQuery();
                    Label1.Visible = true;
                    Label1.Text = "Image Uploaded Sucessfully";
                }
                finally
                {
                    con.Close();
                }
            }

        }
    }
}